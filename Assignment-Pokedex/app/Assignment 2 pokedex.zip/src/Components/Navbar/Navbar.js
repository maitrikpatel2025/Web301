import React from 'react';
import './Navbar.css'

const NavBar =()=>{
    return (
        <section>
        <div className="content">
            <h1>
                PoKeDex
            </h1>
        </div>
        </section>
    )
}
export default NavBar;